from PIL import Image
import numpy as np
import os, os.path, time, sys
import argparse
from imutils import paths
import cv2
import csv


# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--input", required=True,
	            help="path to input image")
args = vars(ap.parse_args())
if args == None:
    raise Exception("could not load image !")

with open("dataset/jaffe_pixels.csv", 'a') as csvfile:
    row = ['emotion', 'pixels', 'Usage']
    writer = csv.writer(csvfile)
    writer.writerow(row)

for inputPath in paths.list_images(args["input"]):

    image = cv2.imread(inputPath)

    label = (inputPath.split("/")[-2])

    print(label)

    usage = 'Training'

    width, height = image.shape[:2]

    # print(image[:, :])

    print(width)
    print(height)

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    value = gray
    print(value.shape)

    value = value.flatten()

    print(len(value))

    n_value = ' '.join(map(str, value))

    row = [label, n_value, usage]
    # print(value)


    with open("dataset/jaffe_pixels.csv", 'a') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(row)



# python3 images_to_csv.py --input dataset/expression/jaffe





# with open('dataset/ck+_pixels.csv') as f:
#     content = f.readlines()
#
# lines = np.array(content)
#
# num_of_instances = lines.size
# num_of_instances = 10
# print("number of instances: ", num_of_instances)
#
# for i in range(1, num_of_instances):
#     emotion, img, usage = lines[i].split(",")
#
#     print(len(img))
#     print(img)
#
#     val = img.split(" ")





# n_value = np.savetxt(sys.stdout, value, fmt="%i")
# with open("dataset/ck+_pixels.csv", 'a') as f:
#     writer = csv.writer(f)
#     writer.writerow(value)
# writer.writerow({'var1': label, 'var2': value, 'var3': usage})
# writer.writerow({'label', 'value', 'usage'})
# fieldnames = ['var1', 'var2', 'var3']
# writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
#
# writer.writeheader()


# #Useful function
# def createFileList(myDir, format='.jpg'):
# fileList = []
# print(myDir)
# for root, dirs, files in os.walk(myDir, topdown=False):
#     for name in files:
#         if name.endswith(format):
#             fullName = os.path.join(root, name)
#             fileList.append(fullName)
# return fileList

# # load the original image
# myFileList = createFileList('/media/ankur/Administrator/Administration/My_Codes/Python/ml/dataset/expression/ck+')
#
# for i in range(0,7):
#
#     os.path.join(myFileList, inputPath.split("/")[-1])
#
# for file in fileList:
#     print(file)
#     img_file = Image.open(file)
#     # img_file.show()
#
#     # get original image parameters...
#     width, height = img_file.size
#     format = img_file.format
#     mode = img_file.mode
#
#     # Make image Greyscale
#     img_grey = img_file.convert('L')
#     #img_grey.save('result.png')
#     #img_grey.show()
#
#     # Save Greyscale values
#     value = np.asarray(img_grey.getdata(), dtype=np.int).reshape((img_grey.size[1], img_grey.size[0]))
#     value = value.flatten()
#     print(value)
#     with open("img_pixels.csv", 'a') as f:
#         writer = csv.writer(f)
#         writer.writerow(value)
#
#
#
# import csv
#
# with open('C:/test/test.csv','r') as csvinput:
#     with open('C:/test/output.csv', 'w') as csvoutput:
#         writer = csv.writer(csvoutput, lineterminator='\n')
#         reader = csv.reader(csvinput)
#
#         all = []
#         row = next(reader)
#         row.append('Berry')
#         all.append(row)
#
#         for row in reader:
#             row.append(row[0])
#             all.append(row)
#
#         writer.writerows(all)
#
#
# from PIL import Image
# import numpy as np
# import os, os.path, time
#
# format='.jpg'
# myDir = "Lotus1"
# def createFileList(myDir, format='.jpg'):
#     fileList = []
#     print(myDir)
#     for root, dirs, files in os.walk(myDir, topdown=False):
#             for name in files:
#                if name.endswith(format):
#                   fullName = os.path.join(root, name)
#                   fileList.append(fullName)
#                   return fileList
#
# fileList = createFileList(myDir)
# fileFormat='.jpg'
# for fileFormat in fileList:
#  format = '.jpg'
#  # get original image parameters...
#  width, height = fileList.size
#  format = fileList.format
#  mode = fileList.mode
#  # Make image Greyscale
#  img_grey = fileList.convert('L')
#  # Save Greyscale values
#  value = np.asarray(fileList.getdata(),dtype=np.float64).reshape((fileList.size[1],fileList.size[0]))
#  np.savetxt("img_pixels.csv", value, delimiter=',')
#
