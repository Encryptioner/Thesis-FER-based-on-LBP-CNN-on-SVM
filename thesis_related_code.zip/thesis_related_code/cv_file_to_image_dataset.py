


import numpy as np
import matplotlib.image as mpim
from matplotlib import cm


with open('dataset/fe/fer2013_modified.csv') as f:
    content = f.readlines()

lines = np.array(content)
num_classes = 7
width = 48
height = 48
a0=0
a1=0
a2=0
a3=0
a4=0
a5=0
a6=0

num_of_instances = lines.size
# num_of_instances = 3
print("number of instances: ", num_of_instances)

for i in range(1, num_of_instances):
    try:
        emotion, img, usage = lines[i].split(",")

        val = img.split(" ")
        pixels = np.array(val, 'float32')

        result = np.fromstring(img, dtype=int, sep=" ").reshape((48, 48))

        # if 'Training' in usage:
        #     name = str(i)+'_training_' + emotion +'.png'
        #
        #     if '0' in emotion:
        #         # mpim.imsave('dataset/fe/train_fer/0/' + name, np.uint8(result), cmap=cm.gray)
        #         a0+=1
        #     if '1' in emotion:
        #         # mpim.imsave('dataset/fe/train_fer/1/' + name, np.uint8(result), cmap=cm.gray)
        #         a1+=1
        #     if '2' in emotion:
        #         # mpim.imsave('dataset/fe/train_fer/2/' + name, np.uint8(result), cmap=cm.gray)
        #         a2+=1
        #     if '3' in emotion:
        #         # mpim.imsave('dataset/fe/train_fer/3/' + name, np.uint8(result), cmap=cm.gray)
        #         a3+=1
        #     if '4' in emotion:
        #         # mpim.imsave('dataset/fe/train_fer/4/' + name, np.uint8(result), cmap=cm.gray)
        #         a4+=1
        #     if '5' in emotion:
        #         # mpim.imsave('dataset/fe/train_fer/5/' + name, np.uint8(result), cmap=cm.gray)
        #         a5+=1
        #     if '6' in emotion:
        #         # mpim.imsave('dataset/fe/train_fer/6/' + name, np.uint8(result), cmap=cm.gray)
        #         a6+=1

        # if 'PublicTest' or 'PrivateTest' in  usage:

        if 'PublicTest' in usage:
            name = str(i) + '_test_' + emotion + '.png'

            if '0' in emotion:
                # mpim.imsave('dataset/fe/test_fer2/0/' + name, np.uint8(result), cmap=cm.gray)
                a0 += 1
            if '1' in emotion:
                # mpim.imsave('dataset/fe/test_fer2/1/' + name, np.uint8(result), cmap=cm.gray)
                a1 += 1
            if '2' in emotion:
                # mpim.imsave('dataset/fe/test_fer2/2/' + name, np.uint8(result), cmap=cm.gray)
                a2 += 1
            if '3' in emotion:
                # mpim.imsave('dataset/fe/test_fer2/3/' + name, np.uint8(result), cmap=cm.gray)
                a3 += 1
            if '4' in emotion:
                # mpim.imsave('dataset/fe/test_fer2/4/' + name, np.uint8(result), cmap=cm.gray)
                a4 += 1
            if '5' in emotion:
                # mpim.imsave('dataset/fe/test_fer2/5/' + name, np.uint8(result), cmap=cm.gray)
                a5 += 1
            if '6' in emotion:
                # mpim.imsave('dataset/fe/test_fer2/6/' + name, np.uint8(result), cmap=cm.gray)
                a6 += 1

    except:

        print(" error occured ", end="")

print('image dataset in .cv format is stored as original image')

print(a0,' ',a1,' ',a2,' ',a3,' ',a4,' ',a5,' ',a6)


